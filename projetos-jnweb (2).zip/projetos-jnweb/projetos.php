<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>JuninhoWeb - Meus Projetos</title>

    <link rel="stylesheet" href="styleprojetos.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

</head>

<body>



    <!--TÍTULO - TOPO DO SITE-->
    <header class="container-topo">



        <img class="img-topo" src="imagens/logo_jn.png" alt="Logo do Juninhoweb" width="80px" height="80px">

        <h1>Meus projetos</h1>



    </header>

    <?php
        include('menu.php');
    ?>


        <!--CARDS CENTRAIS - PROJETOS DESENVOLVIDOS-->
        <div id="container-cards" class="w-75 row align-items-center">
            <!--PRIMEIRA TRÍADE DE CARDS-->
            <div class="card-group">
                <div class="card">
                    <img src="img/logo-vemdezap.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">vemdezap - Gerador de links para WhatsApp</h5>
                        <p class="card-text">Sistema que permite o usuário gerar links para conversas e/ou enviar mensagens via WhatsApp sem a necessidade de salvar o número em sua lista de contatos. Desenvolvido com HTML5, CSS3 e Javascript.</p>
                        <a href="https://www.juninhoweb.com.br/vemdezap" target="_blank" class="btn btn-outline-success">Veja mais</a>

                    </div>
                </div>
                <div class="card">
                    <img src="img/logos-informatica-logo.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Site da escola LOGOS</h5>
                        <p class="card-text">Site desenvolvido como um dos trabalhos do Curso Técnico em Informática do SENAC, utilizando recursos de HTML5, CSS3, Bootstrap, PHP e administração de banco de dados com MySQL. O projeto foi desenvolvido em parceria com mais dois
                            colegas de classe, onde minhas atribuições ficaram relacionadas ao frontend, a criação do logotipo e artefatos gráficos e também da criação e administração dos dados do banco SQL. Os colegas ficaram responsáveis pela construção
                            do backend e interação com o banco.</p>
                        <a href="https://www.juninhoweb.com.br/logosescola" target="_blank" class="btn btn-outline-success">Veja mais</a>
                    </div>
                </div>
                <div class="card">
                    <img src="img/logos-informatica-logo.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Sistema de Gestão Escolar - LOGOS</h5>
                        <p class="card-text">Também desenvolvido como um dos trabalhos do Curso Técnico em Informática do SENAC, onde a proposta foi a criação de um sistema de gestão escolar. Neste projeto foram criados 3 tipos de acesso: o acesso do aluno, o acesso do professor
                            e o acesso do diretor, onde cada tipo de usuário têm acesso às informações pertinentes a sua participação na rotina escolar. Foram utilizados recursos de HTML5, CSS3, Bootstrap, PHP e administração de banco de dados com MySQL.
                            O projeto foi desenvolvido em parceria com mais dois colegas de classe, onde minhas atribuições ficaram relacionadas ao frontend, a criação do logotipo e artefatos gráficos e também da criação e administração dos dados do banco
                            SQL. Os colegas ficaram responsáveis pela construção do backend e interação com o banco.</p>
                        <a href="https://www.juninhoweb.com.br/logos-sge/" class="btn btn-outline-success">Veja mais</a>
                    </div>
                </div>
            </div>

            <!--SEGUNDA TRÍADE DE CARDS-->
            <div class="card-group">
                <div class="card">
                    <img src="img/logo kesia2.png" class="rounded float-start" alt="...">

                    <div class="card-body">
                        <h5 class="card-title">Delícias da Kesia - Logotipo</h5>
                        <p class="card-text">Neste projeto foi desenvolvido um logotipo para o negócio de uma cliente real que comercializa lanches diversos. O projeto foi desenvolvido através do Adobe Illustrator.</p>

                    </div>
                </div>
                <div class="card">
                    <img src="img/Banner Status WhatsApp Kesia2.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Delícias da Kesia - Banner</h5>
                        <p class="card-text">Neste projeto foi desenvolvido um banner cujo objetivo do mesmo é o reaproveitamento da arte para postagens diversas em de status do WhatsApp e/ou story do Instagram, com a finalidade de a cliente anunciar os produtos conforme
                            haja a variedade nos produtos disponíveis para comercialização no dia da publicação do anúncio por parte da mesma.</p>

                    </div>
                </div>
                <div class="card">
                    <img src="img/EDUARDA 3 ANOS.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">3 anos da Eduarda - Convite de aniversário</h5>
                        <p class="card-text">Este foi um dos trabalhos desenvolvidos no curso de Design Gráfico Digital do SENAC, onde foi proposta a criação de um convite de aniversário utilizando recursos do Adobe Photoshop.</p>

                    </div>
                </div>
            </div>

            <!--TERCEIRA TRÍADE DE CARDS-->
            <div class="card-group">
                <div class="card">
                    <img src="img/logo-rosilanches.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Rosi Lanches - Logotipo</h5>
                        <p class="card-text">Logotipo desenvolvido para mais uma cliente real, que possui um negócio autônomo de comercialização de lanches. O logotipo foi desenvolvido conforme gosto e opiniões diretas da cliente, que desejava algo simples porém com detalhes
                            específicos.
                        </p>

                    </div>
                </div>
                <div class="card">
                    <img src="img/banner-status.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Rosi Lanches - Banner</h5>
                        <p class="card-text">Banner desenvolvido para a cliente realizar a divulgação de produtos comercializados através dos status do WhatsApp e story do Instagram.</p>

                    </div>
                </div>
                <div class="card">
                    <img src="img/logo-trainingforce.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Academia Training Force - Logotipo</h5>
                        <p class="card-text">Logotipo desenvolvido para integrar um projeto que será desenvolvido em breve: um site para uma academia.</p>

                    </div>
                </div>
            </div>

            <!--QUARTA TRÍADE DE CARDS-->
            <div class="card-group">
                <div class="card">
                    <img src="img/cardapio-outback.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Cardápio Outback</h5>
                        <p class="card-text">Este foi um dos trabalhos desenvolvidos no curso de Design Gráfico Digital do SENAC, onde foi proposto o desenvolvimento de um cardápio exibindo produtos diversos comercializados pela rede de restaurantes Outback. O trabalho foi
                            desenvolvido utilizando recursos do Adobe InDesign e ajustes de imagens utilizando recursos do Adobe Photoshop.</p>
                        <a href="img/OUTBACK 2k21.pdf" download="OUTBACK 2k21.pdf" class="btn btn-outline-success">Veja o cardápio completo</a>
                    </div>
                </div>
                <div class="card">
                    <img src="img/logo-ecotur.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Logotipo Ecotur</h5>
                        <p class="card-text">Trabalho desenvolvido no curso de Design Gráfico Digital do SENAC, onde foi proposta a criação de um rebranding do logotipo de uma agência de turismo. Neste projeto foram utilizados recursos do Adobe Illustrator.</p>

                    </div>
                </div>
                <div class="card">
                    <img src="img/Logo-estudio-ebenezer.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Studio de Beleza Ebenézer - Logotipo</h5>
                        <p class="card-text">Criação de um logotipo para salão de beleza a por solicitação de uma cliente real. Neste projeto foram utilizados recursos do Adobe Illustrator.</p>
                        <a href="#" class="btn btn-outline-success">Veja mais</a>
                    </div>
                </div>


                <div class="card">
                    <img src="img/banner_salao.png" class="rounded float-start" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Studio de Beleza Ebenézer - Banner</h5>
                        <p class="card-text">Criação de um logotipo para salão de beleza a por solicitação de uma cliente real. Neste projeto foram utilizados recursos do Adobe Illustrator.</p>

                    </div>
                </div>
            </div>

        </div>


        </div>
        </div>


        <!--RODAPÉ DO SITE-->
        <footer class="rodape">
            <p>&copy;2022 JuninhoWeb - Todos os direitos reservados.</p>
        </footer>
</body>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

</html>